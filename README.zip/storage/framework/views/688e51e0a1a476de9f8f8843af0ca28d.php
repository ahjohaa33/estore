    <!-- Footer Nav-->
    <div class="footer-nav-area" id="footerNav">
      <div class="suha-footer-nav">
        <ul class="h-100 d-flex align-items-center justify-content-between ps-0 d-flex rtl-flex-d-row-r">
          <li><a href="home.html"><i class="ti ti-home"></i>Home</a></li>
          <li><a href="message.html"><i class="ti ti-message"></i>Chat</a></li>
          <li><a href="cart.html"><i class="ti ti-basket"></i>Cart</a></li>
          <li><a href="settings.html"><i class="ti ti-settings"></i>Settings</a></li>
          <li><a href="pages.html"><i class="ti ti-heart"></i>Pages</a></li>
        </ul>
      </div>
    </div>
        <!-- All JavaScript Files-->
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.countdown.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.passwordstrength.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/theme-switching.js')); ?>"></script>
    <script src="<?php echo e(asset('js/no-internet.js')); ?>"></script>
    <script src="<?php echo e(asset('js/active.js')); ?>"></script>
    <script src="<?php echo e(asset('js/pwa.js')); ?>"></script>
  </body>
</html><?php /**PATH C:\Users\hp\Desktop\estore\estore\resources\views////partials/footer.blade.php ENDPATH**/ ?>